pip install tk
pip install pillow
pip install googletrans

