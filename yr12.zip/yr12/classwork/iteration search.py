array= [int(1), int(20), int(5), int(3)]
i=0
j=0
n=len(array)
for i in (0, n-1):
    i=j
    while j != 0 and array[j-1]>array[i]:
        term1= array[j-1]
        term2=array[j]
        array[j]=term1
        array[j-1]=term2
        j=j-1
    i=i+1
print(array)
