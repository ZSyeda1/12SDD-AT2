array= []
n=int(input("enter number of values: "))
i=0
for i in range (0,n):
    num= int(input("enter a number: "))
    array.append(num)

search_element= int(input("what number do you want to find: "))
i=0
find = False

while i<n:
    if array[i] == search_element:
        print ("The seach element is found at index:", i)
        find = True
    i=i+1
if find == False:
    print ("The search element was not found")

    
