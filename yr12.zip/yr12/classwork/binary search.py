array= []
n=int(input("enter number of values: "))
i=0

for i in range (0,n):
    num= int(input("enter a number: "))
    array.append(num)
    i=i+1

array.sort()
print("your list is: ", array)

                            
search_element= int(input("what number do you want to find: "))

begin_index=0
end_index= len(array)-1
element_found=False
repeat=True

while element_found==False or begin_index<=end_index:
    mid= int((begin_index+end_index)/2)
    if array[mid] == search_element:
        print ("The seach element is found at index:", i)
        while i>end_index:
            if array[i]== search_element:
                print ("The seach element is found at index:", i)
    elif array[mid]<search_element:
        begin_index=mid+1
        mid= int((begin_index+end_index)/2)
    else:
        if array[mid]>search_element:
            end_index= mid-1
            mid= int((begin_index+end_index)/2)

if element_found==False:
    print("element not in list ")


    
